README

Before running the R-script, please set the working directory to the location of the data.

Please refer to the SUMMARY comments to find the variables that store summary statistics and regression models for each dataset.